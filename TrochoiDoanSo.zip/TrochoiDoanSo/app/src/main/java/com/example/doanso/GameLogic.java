package com.example.doanso;

import java.util.Random;

public class GameLogic {
    private int soBiMat;
    private int soLanDoan;
    private boolean ketThuc;
    private boolean chienThang;

    private static final int SO_LAN_DOAN_TOI_DA = 10;

    // Tạo số bí mật và bắt đầu trò chơi
    public void batDauChoi() {
        Random random = new Random();
        soBiMat = random.nextInt(100) + 1;

        soLanDoan = 0;
        ketThuc = false;
        chienThang = false;
    }

    // Kiểm tra số người chơi đoán
    // Trả về 0 nếu đúng, -1 nếu nhỏ hơn, 1 nếu lớn hơn,
    // -2 nếu số đoán không hợp lệ, -3 nếu trò chơi kết thúc
    public int kiemTraSoDoan(int soDoan) {
        if (ketThuc) {
            return -3;
        }

        if (soDoan < 1 || soDoan > 100) {
            return -2;
        }

        soLanDoan ++;

        if (soDoan == soBiMat) {
            chienThang = true;
            ketThuc = true;
            return 0;
        }

        if (soLanDoan >= SO_LAN_DOAN_TOI_DA) {
            ketThuc = true;
        }

        if (soDoan < soBiMat) {
            return -1;
        } else {
            return 1;
        }
    }

    // Kiểm tra trò chơi đã kết thúc chưa
    public boolean isKetThuc() {
        return ketThuc;
    }

    // Kiểm tra người chơi đã thắng chưa
    public boolean isChienThang() {
        return chienThang;
    }

    // Lấy số bí mật
    public int getSoBiMat() {
        return soBiMat;
    }

    // Lấy số lần đã đoán
    public int getSoLanDoan() {
        return soLanDoan;
    }

    // Lấy số lần đoán tối đa
    public int getSoLanDoanToiDa() {
        return SO_LAN_DOAN_TOI_DA;
    }
}
